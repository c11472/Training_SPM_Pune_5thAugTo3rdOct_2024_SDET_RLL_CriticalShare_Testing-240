package Screenshots;
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
//import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class BaseClass {
	 public static WebDriver driver;
	
	static ExtentReports ext1; // class 
	static ExtentTest test;//interface
	static ExtentSparkReporter testreport;
	
	public static void initialize() throws InterruptedException {
		
        driver = new ChromeDriver();
		driver.get("https://www.google.com");
		
		testreport = new ExtentSparkReporter("./ExtentsHtmlReports/sampleexecutionreport.html"); // path
		ext1=new ExtentReports(); // object
	
		test = ext1.createTest("user.dir", "test");

		
	}
	
	public void captureScreenShots(String methodname) {
		
		try
		{
			File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    FileUtils.copyFile(file, new File("./images/p.jpg"));
		    
		
		}
		catch(Exception e) {
			e.getMessage();
		
		}
		
	}
  
}

