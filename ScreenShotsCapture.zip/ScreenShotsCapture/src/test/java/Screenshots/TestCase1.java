package Screenshots;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.gherkin.model.Scenario;
@Listeners(Screenshots.ListenerClass.class)
public class TestCase1 extends BaseClass{
	@BeforeTest
	public void setup() throws InterruptedException {
		initialize();
	}
	@Test
	public void testMethod1() {
		driver.findElement(null); //failure
		
	}
	
	@AfterTest
	public void tearDown(Scenario scenario) {

		
		driver.quit();
		
	}
	

}
